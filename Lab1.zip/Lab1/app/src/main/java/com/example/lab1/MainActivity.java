package com.example.lab1;

import android.content.res.AssetManager;
import android.os.Bundle;
import android.view.View;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import android.widget.EditText;
import android.widget.TextView;
import java.io.File;
import java.io.PrintWriter;

import java.util.Scanner;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
    }
    public void processPress(View view)
            throws java.io.IOException
    {
        // Get the file names the user typed
        EditText inField = findViewById(R.id.edit_infile);
        EditText outField = findViewById(R.id.edit_outfile);
        TextView status = findViewById(R.id.text_main);

        String inName = inField.getText().toString().trim();
        String outName = outField.getText().toString().trim();

        // Read numbers from the input file (in assets) into the array
        double some_nums[] = new double[300];
        int count = 0;

        AssetManager assetManager = getAssets();
        Scanner fsc = new Scanner(assetManager.open(inName));
        while (fsc.hasNext() && count < some_nums.length) {
            if (fsc.hasNextDouble()) {
                some_nums[count] = fsc.nextDouble();
                count++;
            } else {
                fsc.next();   // not a number, skip it
            }
        }
        fsc.close();

        // Floor the values
        floor_it(some_nums, count);

        // Display them in the TextView
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < count; i++) {
            sb.append(String.format("%.2f", some_nums[i])).append("\n");
        }
        status.setText(sb.toString());

        // Write them to the output file in the external files directory
        File outFile = new File(getExternalFilesDir(null), outName);
        PrintWriter pw = new PrintWriter(outFile);
        for (int i = 0; i < count; i++) {
            pw.printf("%.2f%n", some_nums[i]);
        }
        pw.close();
    } // end processPress
    public void floor_it(double[] a, int num_vals)
    {
        for (int i = 0; i < num_vals; i++) {
        a[i] = Math.floor(a[i]);
    }    } // end floor_it
}